

document.addEventListener('DOMContentLoaded', function () {
	chrome.extension.sendRequest({getTabNames: "requestingTabs"}, function(response) {

		var bg = chrome.extension.getBackgroundPage();
		response.sendingTabObjects;
		var tabs;
		var html = "";

		setTimeout(function(){
			tabs = bg.audibleTabObjects;

			// Adds all audible tabs as a list and stores it in html. The list is added in the next timout function.
			for (var i =0; i < tabs.length; i++) {
		    	html += '<a><li><h5 id = ' + tabs[i].index + '>' + tabs[i].title+ '</h5></li></a>';

		    	// Creates a click listener so that when the user clicks on a tab title, that tab is higlighted
		    	document.body.addEventListener( 'click', function ( event ) {
				    chrome.extension.sendRequest({highlightThisTab: event.target.id});
				} );
			}

			if (tabs.length == 0) {
				html = "There are currently no tabs playing audio";
			}

		}, 100);
		

		// Adds the audible tabs to the popup.html
		setTimeout(function(){
			document.getElementById("audible-tabs").innerHTML = html;
		}, 150);
		

	});

});

