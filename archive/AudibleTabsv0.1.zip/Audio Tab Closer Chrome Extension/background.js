
var audibleTabObjects;
var audibleTabTitles;
var audibleTabIDs;
var audibleTabIndices;
var check;
var formattedTabTitles;

function makeTabsString(audibleTabTitles){
        var result = "These tabs are playing audio:\n\n";
            for (var i = 0; i < audibleTabTitles.length; i++) {
                result += (i + 1) + ") " + audibleTabTitles[i] +"\n\n";
            }

            result += "To close all these tabs, press Ctrl(Command)+Shift+C";

            return result;
}

function printTabs(){
    audibleTabTitles = [];

    chrome.tabs.query({audible: true}, function(tabs){
         tabs.forEach(function(tab){
            audibleTabTitles.push(tab.title);
          });
        check = makeTabsString(audibleTabTitles);
        });

    return check;
}

function getTabObjects(){
    audibleTabObjects = [];

    chrome.tabs.query({audible: true}, function(tabs){
         tabs.forEach(function(tab){
            audibleTabObjects.push(tab);
          });
    });

    return audibleTabObjects;

}

function closeTabs(){
    audibleTabIDs = [];
    var tempTitles = [];

    chrome.tabs.query({audible: true}, function(tabs){
         tabs.forEach(function(tab){
            audibleTabIDs.push(tab.id);
            tempTitles.push(tab.title);
        });

         if (audibleTabIDs.length == 0) {
            alert("There are no tabs to close");
         }
         else{
            chrome.tabs.remove(audibleTabIDs);

            var tabsClosed = "These tabs have been closed:\n\n";
            for (var i = 0; i < tempTitles.length; i++) {
                tabsClosed += (i+1) + ") " + tempTitles[i] + "\n\n";
            }

            alert(tabsClosed);
        }
      });
}


chrome.commands.onCommand.addListener(function (command) {

    // If user presses Ctrl+Shift+A
    if (command === "Show") {
        printTabs();

        var endPrint;
        setTimeout(function(){endPrint = check;},100); 

        // Delay the printing of endPrint so that endPrint correctly initializes with the proper String value after printTabs is called
        setTimeout(function(){ 
            if (endPrint.length > 84) 
                {alert(endPrint);}

            else{
                alert("There are no tabs currently playing audio");
            }; 

        }, 150);
    }

    // If user presses Ctrl+Shift+C
    if (command === "Close") {
        closeTabs();
    }


});

// Returns an array of all audible tab objects when prompted in popup.js
chrome.extension.onRequest.addListener(
  function(request, sender, sendResponse) {
    if (request.getTabNames == "requestingTabs")
      sendResponse({sendingTabObjects: getTabObjects()});
});

// Highlights a given tab
chrome.extension.onRequest.addListener(
    function(request, sender, sendResponse) {
        chrome.tabs.highlight({'tabs': parseInt(request.highlightThisTab)}, function() {});   
    });




