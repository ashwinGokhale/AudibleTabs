# tab-muter
This Google Chrome Extension lets you know what tabs are playing audio and can mute all those tabs or close those tabs.
